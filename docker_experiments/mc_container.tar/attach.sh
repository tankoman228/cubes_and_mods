sudo docker exec -i -t mc_container  /bin/bash #by ID

