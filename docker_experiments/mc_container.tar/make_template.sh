docker build -t pingvin-jdk17 .

